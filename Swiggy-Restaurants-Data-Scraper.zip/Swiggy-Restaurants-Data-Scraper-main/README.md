# Swiggy-Restaurants-Data-Scraper
This repository is having all the codes used to scrape the restaurants data listed on Swiggy in India
